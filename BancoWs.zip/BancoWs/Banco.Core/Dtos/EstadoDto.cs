﻿namespace Banco.Core.Dtos
{
    public class EstadoDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
