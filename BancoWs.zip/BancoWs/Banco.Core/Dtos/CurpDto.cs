﻿namespace Banco.Core.Dtos
{
    public class CurpDto
    {
        public string Curp { get; set; }

        public DateTime Fecha { get; set; }
    }
}
