﻿using Banco.Core.Dtos;
using Banco.Core.IServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;

namespace Banco.Servicios.Renapo
{
    public class CurpServicio: ICurpService
    {  
        //private readonly IHttpClientFactory _httpClientFactory;
        //public CurpServicio(IHttpClientFactory httpClientFactory)
        //{
        //    _httpClientFactory = httpClientFactory;
        //}
        public async Task<string> GenerarCurp(SolicitudDto solicitudDto)
        {
            var client = new HttpClient(); //creamos el cliente
            var request = new HttpRequestMessage(HttpMethod.Post, "https://utilidades.vmartinez84.xyz/api/Curp"); //preparamos la peticion la URL
            request.Headers.Add("accept", "application/json"); //agregamos el encabezado, AGREGAMOS INFORMACION ADICIONAL
            var content = new StringContent(JsonConvert.SerializeObject(solicitudDto), null, "application/json"); //convertimos el objeto a json UTILIZANDO NEWTONSOFT 
            request.Content = content; //asignamos el contenido a la peticion
            var response = await client.SendAsync(request); //enviamos la peticion y esperamos la respuesta
            if (!response.IsSuccessStatusCode) //VERIFICAR SI ESTA DENTRO DEL RANGO DE LOS 200 
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                CurpDto result = JsonConvert.DeserializeObject<CurpDto>(jsonResponse);
                JObject resultado = JObject.Parse(jsonResponse);
                var curp = resultado["curp"];
                return result.Curp;
            }

            return string.Empty;
        }

    }
        
        //public CurpServicio(IHttpClientFactory httpClientFactory)
        //{
        //    _httpClientFactory = httpClientFactory;
        //}
        //public async Task<string> GenerarCurp(SolicitudDto solicitudDeCurpDto)
        //{
        //    const string endpoint = "https://utilidades.vmartinez84.xyz/api/Curp";
        //    var client = _httpClientFactory.CreateClient();
        //    var request = new HttpRequestMessage(HttpMethod.Post, endpoint);
        //    request.Headers.Add("accept", "application/json");
        //    request.Content = new StringContent(JsonConvert.SerializeObject(solicitudDeCurpDto), null, "application/json");
        //    var response = await client.SendAsync(request);
        //    var data = await response.Content.ReadAsStringAsync();
        //    if (response.IsSuccessStatusCode)
        //    {
        //        CurpDto curpDto;

        //        curpDto = JsonConvert.DeserializeObject<CurpDto>(await response.Content.ReadAsStringAsync());

        //        return curpDto.Curp;
        //    }

        //    return string.Empty;
        //}
}
