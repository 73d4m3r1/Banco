# Cliente 

Nombre
PrimerApellido
SegundoApellido
FechaDeNacimiento
EstadoDeNacimiento

# Deposito

ClienteId
NombreDeLaCuenta
